#pragma once
#include <Windows.h>
VOID AdjustProcessPrivilege();